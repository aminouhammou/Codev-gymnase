<?php
session_start();
if(!isset($_COOKIES['CASTGC'])) 
{
header('Location: homePageUser.html');
exit;
}
?>


<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <title>Login</title>
 
    <link rel="stylesheet" type="text/css" href="../css/login.css"/>
    <link rel="stylesheet" type="text/css" href="../css/responsive.css">
</head>
 
<body>
    <section class='fond'>
        <div id="login_frame">
         
            <p id="image_logo"><img src="../images/logo.png" src="IMT LOGO"> </p>
    
 
    <form method="post" action="login.php">
 
            <a href="https://cas.imt-atlantique.fr/cas/login">
            <input type="button" id="btn_login" value="Cliquez ici pour vous identifier" />
            </a>
        </div>  
    </form>
        </div>
    </section>
    <footer>
        
    </footer>

</body>

</html>
