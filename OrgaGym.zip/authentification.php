<?php
function checkuser($name) {
	$bool_check = false;
  	if (strlen($name) > 1) {
  		$bool_check = true;
    }
  return $bool_check;
}
?>

<?php 
function redirect($name) {
    if (isset($_COOKIE[$name])) {
        if (checkuser($_COOKIE[$name])) {
            header("Location: http://localhost/codev/homepage.html");
            exit;
        }
    }
}
?>

